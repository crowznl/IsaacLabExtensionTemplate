"""Locomotion environments for legged robots."""

from .velocity import *  # noqa
