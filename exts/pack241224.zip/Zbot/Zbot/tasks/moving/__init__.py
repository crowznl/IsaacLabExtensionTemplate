"""Locomotion environments for zbot."""

# from .zbot6_direct import *  # noqa

# We leave this file empty since we don't want to expose any configs in this package directly.
